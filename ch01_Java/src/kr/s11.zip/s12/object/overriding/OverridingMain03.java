package kr.s12.object.overriding;

//부모클래스
class People{
	
}

public class OverridingMain03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
